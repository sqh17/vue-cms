//new Vue就需要引Vue
import Vue from 'vue';
//创建Vue对象实例
let Connect = new Vue();

//向外部导出该对象
export default Connect;
