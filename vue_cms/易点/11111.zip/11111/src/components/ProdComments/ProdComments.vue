<template>
   <div>
       <my-title title="留言反馈"></my-title>
       <comment cid="87"></comment>
   </div>
</template>
<script>
   export default {
       data() {
           return {
           }
       }
   }
</script>
<style scoped>
</style>